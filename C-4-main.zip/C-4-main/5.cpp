#include <iostream>
#include <string>
using namespace std;

class Participant {
    string name, gender, maritalStatus, eventName, participantID;
    int age;

public:
    void getData() {
        cout << "Enter Name: "; cin >> name;
        cout << "Enter Age: "; cin >> age;
        cout << "Enter Gender (Male/Female): "; cin >> gender;
        cout << "Enter Marital Status (Single/Married): "; cin >> maritalStatus;
    }

    int getLength() {
        int count = 0;
        for (int i = 0; name[i] != '\0'; i++) count++;
        return count;
    }

    char getInitial() { return name[0]; }

    void getID() {
        participantID = getInitial() + to_string(getLength());
    }

    void toCaps() {
        for (int i = 0; i < name.length(); i++) {
            if (name[i] >= 'a' && name[i] <= 'z') name[i] -= 32;
        }
        
        string prefix = "";
        if (gender == "Male") prefix = (age < 18) ? "Master " : "Mr. ";
        else {
            if (maritalStatus == "Married") prefix = "Mrs. ";
            else prefix = "Miss ";
        }
        name = prefix + name;
    }

    void allotEvent() {
        if (age <= 18) eventName = "Long Jump";
        else if (age > 18 && age <= 50) eventName = "Running";
        else eventName = "Lemon with spoon race";
    }

    void putData() {
        cout << "\n--- Participant Profile ---" << endl;
        cout << "ID: " << participantID << endl;
        cout << "Name: " << name << endl;
        cout << "Event: " << eventName << endl;
    }
};

int main() {
    Participant p;
    p.getData();
    p.getID();
    p.toCaps();
    p.allotEvent();
    p.putData();
    return 0;
}
