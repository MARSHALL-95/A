#include <iostream>
#include <cmath>
using namespace std;

class Polygon {
    int numSides;
    float sideLength;

public:
    void setData(int n, float l) {
        numSides = n;
        sideLength = l;
    }

    void calculateAndDisplay() {
        float perimeter = numSides * sideLength;
        // Area of a regular polygon: (n * s^2) / (4 * tan(PI/n))
        float area = (numSides * pow(sideLength, 2)) / (4 * tan(M_PI / numSides));

        cout << "Perimeter: " << perimeter << endl;
        cout << "Area: " << area << endl;
    }
};

int main() {
    Polygon p;
    p.setData(4, 5.0); // Example: Square with side 5
    p.calculateAndDisplay();
    return 0;
}
