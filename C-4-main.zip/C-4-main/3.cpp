#include <iostream>
using namespace std;

class CarPark {
    int carRegNo;
    int chargePerHour;
    float parkingDuration;

public:
    void setData(int reg, int charge, float duration) {
        carRegNo = reg;
        chargePerHour = charge;
        parkingDuration = duration;
    }

    void showData() {
        cout << "\nCar Reg No: " << carRegNo;
        cout << "\nTotal Charges: " << (chargePerHour * parkingDuration) << " units" << endl;
    }
};

int main() {
    CarPark cp;
    cp.setData(1234, 50, 2.5);
    cp.showData();
    return 0;
}
