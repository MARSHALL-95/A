#include <iostream>
#include <string>
using namespace std;

class Book {
    string title, author, isbn;

public:
    void getBookDetails() {
        cout << "Enter Title: "; getline(cin, title);
        cout << "Enter Author: "; getline(cin, author);
        cout << "Enter ISBN: "; getline(cin, isbn);
    }

    void displayBookDetails() {
        cout << "\n--- Book Details ---" << endl;
        cout << "Title: " << title << "\nAuthor: " << author << "\nISBN: " << isbn << endl;
    }
};

int main() {
    Book myBook;
    myBook.getBookDetails();
    myBook.displayBookDetails();
    return 0;
}
