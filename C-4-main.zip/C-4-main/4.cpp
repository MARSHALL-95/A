#include <iostream>
#include <string>
using namespace std;

class MobilePhone {
    string brand, model;
    float price, batteryLife;

public:
    void storeDetails() {
        cout << "Enter Brand: "; cin >> brand;
        cout << "Enter Model: "; cin >> model;
        cout << "Enter Price: "; cin >> price;
        cout << "Enter Battery Life (hrs): "; cin >> batteryLife;
    }

    void checkAffordability(float budget) {
        if (price <= budget) 
            cout << "The phone is affordable!" << endl;
        else 
            cout << "The phone is out of budget." << endl;
    }
};

int main() {
    MobilePhone mp;
    mp.storeDetails();
    mp.checkAffordability(500.0);
    return 0;
}
